def cargar_archivo(lab):
    return [x.split(" ") for x in [y.strip("\n") for y in open(lab).readlines()]][:-2]

def moverDer(lab, fil, col):
   # print ('MOV derecha', 'fila',fil,'colum',col)
    for x in cargar_archivo(lab)[fil]:
        if(list(x)[col]!=""):
            print(list(x)[col])
            col+=1
            moverDer(lab,fil,col)
            if(list(x)[col+1]!=""):
                
def moverAb(lab, fil, col):
##    print 'MOV Abajo','fila',fil,'colum',col
    for x in cargar_archivo(lab)[fil]:
##        print list(x)[col], 'for abajo'
        if list(x)[col]== '0':
##            print 'hola'
##            abajo(lab,[int(cargar_inicio(lab)[0])+1][0], int(cargar_inicio(lab)[1]))
            if (fil == int(cargar_fin(lab)[0]) and col == int(cargar_fin(lab)[1])):
                print '***********Si existe camino'
                
            abajo(lab, (fil+1), col)
##            print 'REC abajo','FIL', fil, 'COL', col
            der(lab, fil, (col+1))
            izq(lab,fil, (col-1))
##        else:
##            print 'Sale abajo', list(x)[col]
def resolver(lab):
    moverDer(lab,0,0)

resolver("cara.txt") 


